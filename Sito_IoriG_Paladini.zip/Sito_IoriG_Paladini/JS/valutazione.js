let totalQuestions = 20; // Numero totale di domande

function valutaQuiz() {
    let punteggio = 0;

    // Verifica se la checkbox per mostrare le risposte corrette è selezionata
    let showAnswers = document.getElementById('showAnswers').checked;

    // Array per immagazzinare le risposte corrette
    let risposteCorrette = [
        ["Internet Protocol", "aperta"],
        ["false", "vero/falso"],
        ["Long Term Evolution", "aperta"],
        ["Virtualizzazione della rete (vRAN)", "scelta multipla"],
        ["true", "vero/falso"],
        ["handover", "aperta"],
        ["Mobile IP", "aperta"],
        ["10 Gbps", "aperta"],
        ["Maggiore larghezza di banda e bassa latenza nel 5G", "scelta multipla"],
        ["true", "vero/falso"],
        ["Care-Of Address", "aperta"],
        ["false", "vero/falso"],
        ["Tunneling", "aperta"],
        ["eMBB, mMTC, URLLC", "scelta multipla"],
        ["MIP", "scelta multipla"],
        ["Gestire la comunicazione tra celle", "scelta multipla"],
        ["VLR", "aperta"],
        ["false", "vero/falso"],
        ["CDMA", "scelta multipla"],
        ["Frequenza", "aperta"]
    ];    

    for (let i = 1; i <= totalQuestions; i++) {
        let userAnswer = null;
        let rispostaCorrettaElem = document.getElementById('rispostaCorretta' + i);

        if (risposteCorrette[i - 1][1] === "vero/falso") {
            // Vero/Falso
            userAnswer = document.querySelector('input[name="question' + i + '"]:checked');
            if (userAnswer) {
                userAnswer = userAnswer.value;
            } else {
                userAnswer = "";
            }
        } else {
            userAnswer = document.getElementById('question' + i).value.trim().toLowerCase();
        }

        let rispostaCorretta = risposteCorrette[i - 1][0].toLowerCase();

        if (userAnswer === rispostaCorretta) {
            punteggio++;
            applicaStileRisposta(i, true, showAnswers);
            rispostaCorrettaElem.textContent = "";
        } else {
            applicaStileRisposta(i, false, showAnswers, rispostaCorretta);
        }
    }

    // Calcolo del punteggio totale
    let risultato = document.getElementById("risultato");
    risultato.innerHTML = "<p>Punteggio: " + punteggio + " su " + totalQuestions + "</p>";
}

function applicaStileRisposta(numeroDomanda, corretta, showAnswers, rispostaCorretta) {
    // Trova la card della domanda usando l'attributo data-domanda
    let cardDomanda = document.querySelector('.card-domanda[data-domanda="' + numeroDomanda + '"]');

    if (cardDomanda) {
        if (corretta) {
            cardDomanda.style.border = "3px solid green";  // Applica il bordo verde alla card
        } else {
            cardDomanda.style.border = "3px solid red";  // Applica il bordo rosso alla card
            let rispostaCorrettaElem = document.getElementById('rispostaCorretta' + numeroDomanda);
            if (showAnswers) {
                if (rispostaCorrettaElem) {
                    rispostaCorrettaElem.textContent = "Risposta corretta: " + rispostaCorretta;
                    rispostaCorrettaElem.style.display = 'block';  // Mostra la risposta corretta
                }
            } else {
                if (rispostaCorrettaElem) {
                    rispostaCorrettaElem.textContent = "";
                }
            }
        }
    }
}

function resetQuiz() {

    for (let i = 1; i <= totalQuestions; i++) {
        // Resetta gli input radio, select e text
        let inputElements = document.querySelectorAll('input[name="question' + i + '"]');
        let selectElement = document.getElementById('question' + i);
        let textElement = document.getElementById('question' + i);

        if (inputElements.length > 0) {
            inputElements.forEach(function(input) {
                input.checked = false; // Deseleziona i radio button
            });
        }

        if (selectElement) {
            selectElement.selectedIndex = 0; // Reset della select
        }

        if (textElement && textElement.type === 'text') {
            textElement.value = ""; // Reset dei campi di testo
        }

        // Resetta lo stile della card-domanda
        let cardDomanda = document.querySelector('.card-domanda[data-domanda="' + i + '"]');
        if (cardDomanda) {
            cardDomanda.style.border = "";  // Rimuove il bordo dalle card
        }

        // Nascondi il messaggio di risposta corretta
        let rispostaCorrettaElem = document.getElementById('rispostaCorretta' + i);
        if (rispostaCorrettaElem) {
            rispostaCorrettaElem.textContent = "";
            rispostaCorrettaElem.style.display = 'none';  // Nasconde il suggerimento della risposta corretta
        }
    }

    // Resetta il punteggio e il risultato
    let risultato = document.getElementById("risultato");
    risultato.innerHTML = "";  // Pulisce il punteggio visualizzato
}
